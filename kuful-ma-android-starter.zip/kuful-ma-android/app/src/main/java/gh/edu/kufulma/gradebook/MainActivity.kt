package gh.edu.kufulma.gradebook

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

private val Navy = androidx.compose.ui.graphics.Color(0xFF142B4A)
private val Blue = androidx.compose.ui.graphics.Color(0xFF1769AA)
private val Page = androidx.compose.ui.graphics.Color(0xFFF2F6FB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GradebookApp() }
    }
}

@Composable
fun GradebookApp() {
    var signedIn by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf("Dashboard") }
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Blue, secondary = Navy, background = Page)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Page) {
            if (!signedIn) {
                LoginScreen(
                    onContinue = {
                        // Authentication is connected in the next implementation stage.
                        // This temporary preview must not be mistaken for a real login.
                    }
                )
            } else {
                MainShell(selected = selected, onSelect = { selected = it }, onSignOut = { signedIn = false })
            }
        }
    }
}

@Composable
fun LoginScreen(onContinue: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var registering by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("KUFUL M/A", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Navy)
        Text("BASIC SCHOOL GRADEBOOK", style = MaterialTheme.typography.titleMedium, color = Blue)
        Spacer(Modifier.height(28.dp))
        Card {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Text(if (registering) "Create staff account" else "Teacher and Administrator Login",
                    style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                if (registering) {
                    OutlinedTextField(fullName, { fullName = it }, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedTextField(email, { email = it }, label = { Text("Email address") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(password, { password = it }, label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(16.dp))
                Button(onClick = onContinue, modifier = Modifier.fillMaxWidth(), enabled = false) {
                    Text(if (registering) "Create account" else "Sign in")
                }
                Text(
                    "Account connection is being configured. Sign-in is not active in this preview build.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error
                )
                TextButton(onClick = { registering = !registering }) {
                    Text(if (registering) "Already registered? Sign in" else "Create staff account")
                }
            }
        }
    }
}

@Composable
fun MainShell(selected: String, onSelect: (String) -> Unit, onSignOut: () -> Unit) {
    val tabs = listOf("Dashboard", "Students", "Assessments", "Enter Marks", "Attendance")
    Scaffold(
        topBar = {
            TopAppBarCompat(title = "Kuful M/A Gradebook", onSignOut = onSignOut)
        },
        bottomBar = {
            NavigationBar {
                tabs.take(3).forEach { item ->
                    NavigationBarItem(
                        selected = selected == item, onClick = { onSelect(item) },
                        icon = { Icon(Icons.Default.Home, contentDescription = null) },
                        label = { Text(item) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
            Text(selected, style = MaterialTheme.typography.headlineSmall, color = Navy, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            when (selected) {
                "Dashboard" -> {
                    Text("Basic 7 • Basic 8 • Basic 9")
                    Spacer(Modifier.height(12.dp))
                    listOf("Student Register", "Assessments", "Marks Entry", "Teacher Attendance").forEach {
                        Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.School, contentDescription = null, tint = Blue)
                                Spacer(Modifier.width(12.dp))
                                Text(it, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
                else -> Text("$selected module will be connected to the school database in the next build.")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarCompat(title: String, onSignOut: () -> Unit) {
    TopAppBar(
        title = { Text(title, fontWeight = FontWeight.Bold) },
        actions = { IconButton(onClick = onSignOut) { Icon(Icons.Default.Logout, contentDescription = "Sign out") } }
    )
}
