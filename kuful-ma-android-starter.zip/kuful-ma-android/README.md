# Kuful M/A Gradebook — Android

Native Android project using Kotlin and Jetpack Compose.

## Current stage
This is the initial native project scaffold. It includes the Android app structure, a first-pass login/register screen design, placeholder gradebook navigation, and a GitHub Actions workflow to build a debug APK.

**Authentication and database actions are intentionally disabled in this scaffold.** The next implementation stage must connect Supabase Auth, profile roles, and the existing tables before the app is used with real school data.

## Build
Open this `android` folder in Android Studio, or run:

```bash
gradle assembleDebug
```

GitHub Actions builds an APK when files under `android/` change or when manually triggered.

## Supabase project
The existing school database is retained. Do not put a Supabase service-role or secret key in the Android app. Use only the project's publishable key and enforce access with the existing Row Level Security policies.
