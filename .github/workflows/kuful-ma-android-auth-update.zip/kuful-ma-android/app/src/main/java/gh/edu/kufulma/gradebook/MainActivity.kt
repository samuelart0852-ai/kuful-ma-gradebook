package gh.edu.kufulma.gradebook

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.providers.builtin.Email
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import io.github.jan.supabase.auth.handleDeeplinks
import kotlinx.coroutines.launch

private val Navy = Color(0xFF142B4A)
private val Blue = Color(0xFF1769AA)
private val Page = Color(0xFFF2F6FB)

private object SupabaseProvider {
    val client = createSupabaseClient(
        supabaseUrl = BuildConfig.SUPABASE_URL,
        supabaseKey = BuildConfig.SUPABASE_PUBLISHABLE_KEY
    ) {
        install(Auth) {
            scheme = "kufulgradebook"
            host = "auth"
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SupabaseProvider.client.handleDeeplinks(intent)
        setContent { GradebookApp() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        SupabaseProvider.client.handleDeeplinks(intent)
    }
}

@Composable
fun GradebookApp() {
    var signedIn by remember { mutableStateOf(false) }
    var checkingSession by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf("Dashboard") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        signedIn = runCatching { SupabaseProvider.client.auth.currentSessionOrNull() != null }.getOrDefault(false)
        checkingSession = false
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Navy, background = Page)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Page) {
            when {
                checkingSession -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                !signedIn -> LoginScreen(
                    onSignIn = { email, password ->
                        SupabaseProvider.client.auth.signInWith(Email) {
                            this.email = email
                            this.password = password
                        }
                        signedIn = true
                    },
                    onRegister = { name, email, password ->
                        SupabaseProvider.client.auth.signUpWith(
                            Email,
                            redirectUrl = "kufulgradebook://auth"
                        ) {
                            this.email = email
                            this.password = password
                            data = buildJsonObject {
                                put("full_name", name)
                            }
                        }
                    }
                )
                else -> MainShell(
                    selected = selected,
                    onSelect = { selected = it },
                    onSignOut = {
                        scope.launch {
                            SupabaseProvider.client.auth.signOut()
                            signedIn = false
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun LoginScreen(
    onSignIn: suspend (String, String) -> Unit,
    onRegister: suspend (String, String, String) -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var registering by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("KUFUL M/A", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Navy)
        Text("BASIC SCHOOL GRADEBOOK", style = MaterialTheme.typography.titleMedium, color = Blue)
        Spacer(Modifier.height(28.dp))
        Card {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Text(
                    if (registering) "Create staff account" else "Teacher and Administrator Login",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(16.dp))
                if (registering) {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Full name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email address") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = {
                        message = ""
                        if (email.isBlank() || password.length < 6 || (registering && fullName.isBlank())) {
                            message = "Enter your details. Password must be at least 6 characters."
                        } else {
                            scope.launch {
                                loading = true
                                try {
                                    if (registering) {
                                        onRegister(fullName.trim(), email.trim(), password)
                                        message = "Registration submitted. Check your email to confirm your account, then sign in."
                                        registering = false
                                    } else {
                                        onSignIn(email.trim(), password)
                                    }
                                } catch (e: Exception) {
                                    message = e.message?.substringBefore("\n") ?: "Authentication failed. Check your details and internet connection."
                                } finally {
                                    loading = false
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !loading
                ) {
                    if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    else Text(if (registering) "Create account" else "Sign in")
                }
                if (message.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
                TextButton(onClick = { registering = !registering; message = "" }) {
                    Text(if (registering) "Already registered? Sign in" else "Create staff account")
                }
            }
        }
    }
}

@Composable
fun MainShell(selected: String, onSelect: (String) -> Unit, onSignOut: () -> Unit) {
    val tabs = listOf("Dashboard", "Students", "Assessments", "Enter Marks", "Attendance")
    Scaffold(
        topBar = { TopAppBarCompat(title = "Kuful M/A Gradebook", onSignOut = onSignOut) },
        bottomBar = {
            NavigationBar {
                tabs.take(3).forEach { item ->
                    NavigationBarItem(
                        selected = selected == item,
                        onClick = { onSelect(item) },
                        icon = { Icon(Icons.Default.School, contentDescription = null) },
                        label = { Text(item) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
            Text(selected, style = MaterialTheme.typography.headlineSmall, color = Navy, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            if (selected == "Dashboard") {
                Text("Welcome to Kuful M/A Basic School")
                Spacer(Modifier.height(12.dp))
                listOf("Basic 7", "Basic 8", "Basic 9").forEach {
                    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.School, contentDescription = null, tint = Blue)
                            Spacer(Modifier.width(12.dp))
                            Text(it, fontWeight = FontWeight.Medium)
                        }
                    }
                }
                Text("Your account is authenticated. Student and assessment modules will be connected next.", style = MaterialTheme.typography.bodySmall)
            } else {
                Text("$selected module will be connected to the school database in the next build.")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarCompat(title: String, onSignOut: () -> Unit) {
    TopAppBar(
        title = { Text(title, fontWeight = FontWeight.Bold) },
        actions = { IconButton(onClick = onSignOut) { Icon(Icons.Default.Logout, contentDescription = "Sign out") } }
    )
}
