# Kuful M/A Gradebook — Android

Native Android app using Kotlin and Jetpack Compose.

## Current implementation
- Email/password sign-in connected to the existing Supabase Auth project.
- Staff account registration with email confirmation deep link support.
- Supabase publishable key only. Never add a service-role or secret key to this app.
- Student, assessment, marks and attendance modules are still placeholders and will be connected in later builds.

## Build
Run `gradle assembleDebug` from this project directory.

## Supabase configuration
Add this exact redirect URL to Supabase Authentication > URL Configuration > Redirect URLs:

`kufulgradebook://auth`

Project URL and publishable key are configured in `app/build.gradle.kts`. The publishable key is intended for client applications. Keep Row Level Security enabled on all school data tables.
